
package failre;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "resourceMessageID",
    "resourceStatusCode",
    "processMessages"
})
public class ResourceMessage implements Serializable
{

    @JsonProperty("resourceMessageID")
    private ResourceMessageID resourceMessageID;
    @JsonProperty("resourceStatusCode")
    private ResourceStatusCode resourceStatusCode;
    @JsonProperty("processMessages")
    private List<ProcessMessage> processMessages = null;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();
    private final static long serialVersionUID = 4732218627070429592L;

    @JsonProperty("resourceMessageID")
    public ResourceMessageID getResourceMessageID() {
        return resourceMessageID;
    }

    @JsonProperty("resourceMessageID")
    public void setResourceMessageID(ResourceMessageID resourceMessageID) {
        this.resourceMessageID = resourceMessageID;
    }

    @JsonProperty("resourceStatusCode")
    public ResourceStatusCode getResourceStatusCode() {
        return resourceStatusCode;
    }

    @JsonProperty("resourceStatusCode")
    public void setResourceStatusCode(ResourceStatusCode resourceStatusCode) {
        this.resourceStatusCode = resourceStatusCode;
    }

    @JsonProperty("processMessages")
    public List<ProcessMessage> getProcessMessages() {
        return processMessages;
    }

    @JsonProperty("processMessages")
    public void setProcessMessages(List<ProcessMessage> processMessages) {
        this.processMessages = processMessages;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("resourceMessageID", resourceMessageID).append("resourceStatusCode", resourceStatusCode).append("processMessages", processMessages).append("additionalProperties", additionalProperties).toString();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(processMessages).append(additionalProperties).append(resourceMessageID).append(resourceStatusCode).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof ResourceMessage) == false) {
            return false;
        }
        ResourceMessage rhs = ((ResourceMessage) other);
        return new EqualsBuilder().append(processMessages, rhs.processMessages).append(additionalProperties, rhs.additionalProperties).append(resourceMessageID, rhs.resourceMessageID).append(resourceStatusCode, rhs.resourceStatusCode).isEquals();
    }

}
