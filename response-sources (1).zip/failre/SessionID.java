
package failre;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "idValue",
    "schemeName",
    "schemeAgencyName"
})
public class SessionID implements Serializable
{

    @JsonProperty("idValue")
    private String idValue;
    @JsonProperty("schemeName")
    private String schemeName;
    @JsonProperty("schemeAgencyName")
    private String schemeAgencyName;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();
    private final static long serialVersionUID = -5205235700663445917L;

    @JsonProperty("idValue")
    public String getIdValue() {
        return idValue;
    }

    @JsonProperty("idValue")
    public void setIdValue(String idValue) {
        this.idValue = idValue;
    }

    @JsonProperty("schemeName")
    public String getSchemeName() {
        return schemeName;
    }

    @JsonProperty("schemeName")
    public void setSchemeName(String schemeName) {
        this.schemeName = schemeName;
    }

    @JsonProperty("schemeAgencyName")
    public String getSchemeAgencyName() {
        return schemeAgencyName;
    }

    @JsonProperty("schemeAgencyName")
    public void setSchemeAgencyName(String schemeAgencyName) {
        this.schemeAgencyName = schemeAgencyName;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("idValue", idValue).append("schemeName", schemeName).append("schemeAgencyName", schemeAgencyName).append("additionalProperties", additionalProperties).toString();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(schemeName).append(idValue).append(additionalProperties).append(schemeAgencyName).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof SessionID) == false) {
            return false;
        }
        SessionID rhs = ((SessionID) other);
        return new EqualsBuilder().append(schemeName, rhs.schemeName).append(idValue, rhs.idValue).append(additionalProperties, rhs.additionalProperties).append(schemeAgencyName, rhs.schemeAgencyName).isEquals();
    }

}
