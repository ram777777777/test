
package failre;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "processMessageID",
    "resourceStatusCode",
    "messageTypeCode",
    "userMessage"
})
public class ProcessMessage implements Serializable
{

    @JsonProperty("processMessageID")
    private ProcessMessageID processMessageID;
    @JsonProperty("resourceStatusCode")
    private ResourceStatusCode_ resourceStatusCode;
    @JsonProperty("messageTypeCode")
    private MessageTypeCode messageTypeCode;
    @JsonProperty("userMessage")
    private UserMessage userMessage;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();
    private final static long serialVersionUID = 2957167494726755001L;

    @JsonProperty("processMessageID")
    public ProcessMessageID getProcessMessageID() {
        return processMessageID;
    }

    @JsonProperty("processMessageID")
    public void setProcessMessageID(ProcessMessageID processMessageID) {
        this.processMessageID = processMessageID;
    }

    @JsonProperty("resourceStatusCode")
    public ResourceStatusCode_ getResourceStatusCode() {
        return resourceStatusCode;
    }

    @JsonProperty("resourceStatusCode")
    public void setResourceStatusCode(ResourceStatusCode_ resourceStatusCode) {
        this.resourceStatusCode = resourceStatusCode;
    }

    @JsonProperty("messageTypeCode")
    public MessageTypeCode getMessageTypeCode() {
        return messageTypeCode;
    }

    @JsonProperty("messageTypeCode")
    public void setMessageTypeCode(MessageTypeCode messageTypeCode) {
        this.messageTypeCode = messageTypeCode;
    }

    @JsonProperty("userMessage")
    public UserMessage getUserMessage() {
        return userMessage;
    }

    @JsonProperty("userMessage")
    public void setUserMessage(UserMessage userMessage) {
        this.userMessage = userMessage;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("processMessageID", processMessageID).append("resourceStatusCode", resourceStatusCode).append("messageTypeCode", messageTypeCode).append("userMessage", userMessage).append("additionalProperties", additionalProperties).toString();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(userMessage).append(processMessageID).append(messageTypeCode).append(additionalProperties).append(resourceStatusCode).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof ProcessMessage) == false) {
            return false;
        }
        ProcessMessage rhs = ((ProcessMessage) other);
        return new EqualsBuilder().append(userMessage, rhs.userMessage).append(processMessageID, rhs.processMessageID).append(messageTypeCode, rhs.messageTypeCode).append(additionalProperties, rhs.additionalProperties).append(resourceStatusCode, rhs.resourceStatusCode).isEquals();
    }

}
