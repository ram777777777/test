
package failre;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "confirmMessageID",
    "createDateTime",
    "requestReceiptDateTime",
    "protocolStatusCode",
    "protocolCode",
    "requestStatusCode",
    "requestMethodCode",
    "sessionID",
    "requestETag",
    "requestLink",
    "resourceMessages"
})
public class ConfirmMessage implements Serializable
{

    @JsonProperty("confirmMessageID")
    private ConfirmMessageID confirmMessageID;
    @JsonProperty("createDateTime")
    private String createDateTime;
    @JsonProperty("requestReceiptDateTime")
    private String requestReceiptDateTime;
    @JsonProperty("protocolStatusCode")
    private ProtocolStatusCode protocolStatusCode;
    @JsonProperty("protocolCode")
    private ProtocolCode protocolCode;
    @JsonProperty("requestStatusCode")
    private RequestStatusCode requestStatusCode;
    @JsonProperty("requestMethodCode")
    private RequestMethodCode requestMethodCode;
    @JsonProperty("sessionID")
    private SessionID sessionID;
    @JsonProperty("requestETag")
    private String requestETag;
    @JsonProperty("requestLink")
    private RequestLink requestLink;
    @JsonProperty("resourceMessages")
    private List<ResourceMessage> resourceMessages = null;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();
    private final static long serialVersionUID = -6004162271203358764L;

    @JsonProperty("confirmMessageID")
    public ConfirmMessageID getConfirmMessageID() {
        return confirmMessageID;
    }

    @JsonProperty("confirmMessageID")
    public void setConfirmMessageID(ConfirmMessageID confirmMessageID) {
        this.confirmMessageID = confirmMessageID;
    }

    @JsonProperty("createDateTime")
    public String getCreateDateTime() {
        return createDateTime;
    }

    @JsonProperty("createDateTime")
    public void setCreateDateTime(String createDateTime) {
        this.createDateTime = createDateTime;
    }

    @JsonProperty("requestReceiptDateTime")
    public String getRequestReceiptDateTime() {
        return requestReceiptDateTime;
    }

    @JsonProperty("requestReceiptDateTime")
    public void setRequestReceiptDateTime(String requestReceiptDateTime) {
        this.requestReceiptDateTime = requestReceiptDateTime;
    }

    @JsonProperty("protocolStatusCode")
    public ProtocolStatusCode getProtocolStatusCode() {
        return protocolStatusCode;
    }

    @JsonProperty("protocolStatusCode")
    public void setProtocolStatusCode(ProtocolStatusCode protocolStatusCode) {
        this.protocolStatusCode = protocolStatusCode;
    }

    @JsonProperty("protocolCode")
    public ProtocolCode getProtocolCode() {
        return protocolCode;
    }

    @JsonProperty("protocolCode")
    public void setProtocolCode(ProtocolCode protocolCode) {
        this.protocolCode = protocolCode;
    }

    @JsonProperty("requestStatusCode")
    public RequestStatusCode getRequestStatusCode() {
        return requestStatusCode;
    }

    @JsonProperty("requestStatusCode")
    public void setRequestStatusCode(RequestStatusCode requestStatusCode) {
        this.requestStatusCode = requestStatusCode;
    }

    @JsonProperty("requestMethodCode")
    public RequestMethodCode getRequestMethodCode() {
        return requestMethodCode;
    }

    @JsonProperty("requestMethodCode")
    public void setRequestMethodCode(RequestMethodCode requestMethodCode) {
        this.requestMethodCode = requestMethodCode;
    }

    @JsonProperty("sessionID")
    public SessionID getSessionID() {
        return sessionID;
    }

    @JsonProperty("sessionID")
    public void setSessionID(SessionID sessionID) {
        this.sessionID = sessionID;
    }

    @JsonProperty("requestETag")
    public String getRequestETag() {
        return requestETag;
    }

    @JsonProperty("requestETag")
    public void setRequestETag(String requestETag) {
        this.requestETag = requestETag;
    }

    @JsonProperty("requestLink")
    public RequestLink getRequestLink() {
        return requestLink;
    }

    @JsonProperty("requestLink")
    public void setRequestLink(RequestLink requestLink) {
        this.requestLink = requestLink;
    }

    @JsonProperty("resourceMessages")
    public List<ResourceMessage> getResourceMessages() {
        return resourceMessages;
    }

    @JsonProperty("resourceMessages")
    public void setResourceMessages(List<ResourceMessage> resourceMessages) {
        this.resourceMessages = resourceMessages;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("confirmMessageID", confirmMessageID).append("createDateTime", createDateTime).append("requestReceiptDateTime", requestReceiptDateTime).append("protocolStatusCode", protocolStatusCode).append("protocolCode", protocolCode).append("requestStatusCode", requestStatusCode).append("requestMethodCode", requestMethodCode).append("sessionID", sessionID).append("requestETag", requestETag).append("requestLink", requestLink).append("resourceMessages", resourceMessages).append("additionalProperties", additionalProperties).toString();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(requestLink).append(confirmMessageID).append(requestETag).append(requestMethodCode).append(sessionID).append(createDateTime).append(resourceMessages).append(protocolCode).append(requestStatusCode).append(protocolStatusCode).append(additionalProperties).append(requestReceiptDateTime).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof ConfirmMessage) == false) {
            return false;
        }
        ConfirmMessage rhs = ((ConfirmMessage) other);
        return new EqualsBuilder().append(requestLink, rhs.requestLink).append(confirmMessageID, rhs.confirmMessageID).append(requestETag, rhs.requestETag).append(requestMethodCode, rhs.requestMethodCode).append(sessionID, rhs.sessionID).append(createDateTime, rhs.createDateTime).append(resourceMessages, rhs.resourceMessages).append(protocolCode, rhs.protocolCode).append(requestStatusCode, rhs.requestStatusCode).append(protocolStatusCode, rhs.protocolStatusCode).append(additionalProperties, rhs.additionalProperties).append(requestReceiptDateTime, rhs.requestReceiptDateTime).isEquals();
    }

}
