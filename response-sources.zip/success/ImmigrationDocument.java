
package success;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "documentID",
    "countryCode",
    "typeCode",
    "issuingParty",
    "issueDate",
    "expirationDate",
    "authorizedStayDuration",
    "reentryRequirementDuration"
})
public class ImmigrationDocument implements Serializable
{

    @JsonProperty("documentID")
    private String documentID;
    @JsonProperty("countryCode")
    private String countryCode;
    @JsonProperty("typeCode")
    private TypeCode typeCode;
    @JsonProperty("issuingParty")
    private IssuingParty issuingParty;
    @JsonProperty("issueDate")
    private String issueDate;
    @JsonProperty("expirationDate")
    private String expirationDate;
    @JsonProperty("authorizedStayDuration")
    private String authorizedStayDuration;
    @JsonProperty("reentryRequirementDuration")
    private String reentryRequirementDuration;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();
    private final static long serialVersionUID = -5558081340168356733L;

    @JsonProperty("documentID")
    public String getDocumentID() {
        return documentID;
    }

    @JsonProperty("documentID")
    public void setDocumentID(String documentID) {
        this.documentID = documentID;
    }

    @JsonProperty("countryCode")
    public String getCountryCode() {
        return countryCode;
    }

    @JsonProperty("countryCode")
    public void setCountryCode(String countryCode) {
        this.countryCode = countryCode;
    }

    @JsonProperty("typeCode")
    public TypeCode getTypeCode() {
        return typeCode;
    }

    @JsonProperty("typeCode")
    public void setTypeCode(TypeCode typeCode) {
        this.typeCode = typeCode;
    }

    @JsonProperty("issuingParty")
    public IssuingParty getIssuingParty() {
        return issuingParty;
    }

    @JsonProperty("issuingParty")
    public void setIssuingParty(IssuingParty issuingParty) {
        this.issuingParty = issuingParty;
    }

    @JsonProperty("issueDate")
    public String getIssueDate() {
        return issueDate;
    }

    @JsonProperty("issueDate")
    public void setIssueDate(String issueDate) {
        this.issueDate = issueDate;
    }

    @JsonProperty("expirationDate")
    public String getExpirationDate() {
        return expirationDate;
    }

    @JsonProperty("expirationDate")
    public void setExpirationDate(String expirationDate) {
        this.expirationDate = expirationDate;
    }

    @JsonProperty("authorizedStayDuration")
    public String getAuthorizedStayDuration() {
        return authorizedStayDuration;
    }

    @JsonProperty("authorizedStayDuration")
    public void setAuthorizedStayDuration(String authorizedStayDuration) {
        this.authorizedStayDuration = authorizedStayDuration;
    }

    @JsonProperty("reentryRequirementDuration")
    public String getReentryRequirementDuration() {
        return reentryRequirementDuration;
    }

    @JsonProperty("reentryRequirementDuration")
    public void setReentryRequirementDuration(String reentryRequirementDuration) {
        this.reentryRequirementDuration = reentryRequirementDuration;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("documentID", documentID).append("countryCode", countryCode).append("typeCode", typeCode).append("issuingParty", issuingParty).append("issueDate", issueDate).append("expirationDate", expirationDate).append("authorizedStayDuration", authorizedStayDuration).append("reentryRequirementDuration", reentryRequirementDuration).append("additionalProperties", additionalProperties).toString();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(countryCode).append(authorizedStayDuration).append(reentryRequirementDuration).append(documentID).append(additionalProperties).append(issueDate).append(issuingParty).append(typeCode).append(expirationDate).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof ImmigrationDocument) == false) {
            return false;
        }
        ImmigrationDocument rhs = ((ImmigrationDocument) other);
        return new EqualsBuilder().append(countryCode, rhs.countryCode).append(authorizedStayDuration, rhs.authorizedStayDuration).append(reentryRequirementDuration, rhs.reentryRequirementDuration).append(documentID, rhs.documentID).append(additionalProperties, rhs.additionalProperties).append(issueDate, rhs.issueDate).append(issuingParty, rhs.issuingParty).append(typeCode, rhs.typeCode).append(expirationDate, rhs.expirationDate).isEquals();
    }

}
