
package success;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "amountValue",
    "unitCode",
    "baseUnitCode"
})
public class Rate implements Serializable
{

    @JsonProperty("amountValue")
    private Integer amountValue;
    @JsonProperty("unitCode")
    private UnitCode__ unitCode;
    @JsonProperty("baseUnitCode")
    private BaseUnitCode_ baseUnitCode;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();
    private final static long serialVersionUID = 7300849808815368490L;

    @JsonProperty("amountValue")
    public Integer getAmountValue() {
        return amountValue;
    }

    @JsonProperty("amountValue")
    public void setAmountValue(Integer amountValue) {
        this.amountValue = amountValue;
    }

    @JsonProperty("unitCode")
    public UnitCode__ getUnitCode() {
        return unitCode;
    }

    @JsonProperty("unitCode")
    public void setUnitCode(UnitCode__ unitCode) {
        this.unitCode = unitCode;
    }

    @JsonProperty("baseUnitCode")
    public BaseUnitCode_ getBaseUnitCode() {
        return baseUnitCode;
    }

    @JsonProperty("baseUnitCode")
    public void setBaseUnitCode(BaseUnitCode_ baseUnitCode) {
        this.baseUnitCode = baseUnitCode;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("amountValue", amountValue).append("unitCode", unitCode).append("baseUnitCode", baseUnitCode).append("additionalProperties", additionalProperties).toString();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(amountValue).append(additionalProperties).append(baseUnitCode).append(unitCode).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof Rate) == false) {
            return false;
        }
        Rate rhs = ((Rate) other);
        return new EqualsBuilder().append(amountValue, rhs.amountValue).append(additionalProperties, rhs.additionalProperties).append(baseUnitCode, rhs.baseUnitCode).append(unitCode, rhs.unitCode).isEquals();
    }

}
