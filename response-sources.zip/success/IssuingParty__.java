
package success;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "nameCode",
    "address"
})
public class IssuingParty__ implements Serializable
{

    @JsonProperty("nameCode")
    private NameCode___ nameCode;
    @JsonProperty("address")
    private Address__ address;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();
    private final static long serialVersionUID = 540100436558534804L;

    @JsonProperty("nameCode")
    public NameCode___ getNameCode() {
        return nameCode;
    }

    @JsonProperty("nameCode")
    public void setNameCode(NameCode___ nameCode) {
        this.nameCode = nameCode;
    }

    @JsonProperty("address")
    public Address__ getAddress() {
        return address;
    }

    @JsonProperty("address")
    public void setAddress(Address__ address) {
        this.address = address;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("nameCode", nameCode).append("address", address).append("additionalProperties", additionalProperties).toString();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(address).append(additionalProperties).append(nameCode).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof IssuingParty__) == false) {
            return false;
        }
        IssuingParty__ rhs = ((IssuingParty__) other);
        return new EqualsBuilder().append(address, rhs.address).append(additionalProperties, rhs.additionalProperties).append(nameCode, rhs.nameCode).isEquals();
    }

}
