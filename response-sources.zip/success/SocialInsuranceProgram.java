
package success;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "itemID",
    "nameCode",
    "countryCode",
    "coveredIndicator"
})
public class SocialInsuranceProgram implements Serializable
{

    @JsonProperty("itemID")
    private String itemID;
    @JsonProperty("nameCode")
    private NameCode nameCode;
    @JsonProperty("countryCode")
    private String countryCode;
    @JsonProperty("coveredIndicator")
    private Boolean coveredIndicator;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();
    private final static long serialVersionUID = 3131172521474994063L;

    @JsonProperty("itemID")
    public String getItemID() {
        return itemID;
    }

    @JsonProperty("itemID")
    public void setItemID(String itemID) {
        this.itemID = itemID;
    }

    @JsonProperty("nameCode")
    public NameCode getNameCode() {
        return nameCode;
    }

    @JsonProperty("nameCode")
    public void setNameCode(NameCode nameCode) {
        this.nameCode = nameCode;
    }

    @JsonProperty("countryCode")
    public String getCountryCode() {
        return countryCode;
    }

    @JsonProperty("countryCode")
    public void setCountryCode(String countryCode) {
        this.countryCode = countryCode;
    }

    @JsonProperty("coveredIndicator")
    public Boolean getCoveredIndicator() {
        return coveredIndicator;
    }

    @JsonProperty("coveredIndicator")
    public void setCoveredIndicator(Boolean coveredIndicator) {
        this.coveredIndicator = coveredIndicator;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("itemID", itemID).append("nameCode", nameCode).append("countryCode", countryCode).append("coveredIndicator", coveredIndicator).append("additionalProperties", additionalProperties).toString();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(itemID).append(coveredIndicator).append(additionalProperties).append(nameCode).append(countryCode).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof SocialInsuranceProgram) == false) {
            return false;
        }
        SocialInsuranceProgram rhs = ((SocialInsuranceProgram) other);
        return new EqualsBuilder().append(itemID, rhs.itemID).append(coveredIndicator, rhs.coveredIndicator).append(additionalProperties, rhs.additionalProperties).append(nameCode, rhs.nameCode).append(countryCode, rhs.countryCode).isEquals();
    }

}
