
package success;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "formattedBirthPlace",
    "cityName",
    "countrySubdivisionLevel1",
    "postalCode",
    "countryCode"
})
public class BirthPlace implements Serializable
{

    @JsonProperty("formattedBirthPlace")
    private String formattedBirthPlace;
    @JsonProperty("cityName")
    private String cityName;
    @JsonProperty("countrySubdivisionLevel1")
    private CountrySubdivisionLevel1___ countrySubdivisionLevel1;
    @JsonProperty("postalCode")
    private String postalCode;
    @JsonProperty("countryCode")
    private String countryCode;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();
    private final static long serialVersionUID = -3149908196358976976L;

    @JsonProperty("formattedBirthPlace")
    public String getFormattedBirthPlace() {
        return formattedBirthPlace;
    }

    @JsonProperty("formattedBirthPlace")
    public void setFormattedBirthPlace(String formattedBirthPlace) {
        this.formattedBirthPlace = formattedBirthPlace;
    }

    @JsonProperty("cityName")
    public String getCityName() {
        return cityName;
    }

    @JsonProperty("cityName")
    public void setCityName(String cityName) {
        this.cityName = cityName;
    }

    @JsonProperty("countrySubdivisionLevel1")
    public CountrySubdivisionLevel1___ getCountrySubdivisionLevel1() {
        return countrySubdivisionLevel1;
    }

    @JsonProperty("countrySubdivisionLevel1")
    public void setCountrySubdivisionLevel1(CountrySubdivisionLevel1___ countrySubdivisionLevel1) {
        this.countrySubdivisionLevel1 = countrySubdivisionLevel1;
    }

    @JsonProperty("postalCode")
    public String getPostalCode() {
        return postalCode;
    }

    @JsonProperty("postalCode")
    public void setPostalCode(String postalCode) {
        this.postalCode = postalCode;
    }

    @JsonProperty("countryCode")
    public String getCountryCode() {
        return countryCode;
    }

    @JsonProperty("countryCode")
    public void setCountryCode(String countryCode) {
        this.countryCode = countryCode;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("formattedBirthPlace", formattedBirthPlace).append("cityName", cityName).append("countrySubdivisionLevel1", countrySubdivisionLevel1).append("postalCode", postalCode).append("countryCode", countryCode).append("additionalProperties", additionalProperties).toString();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(cityName).append(countryCode).append(postalCode).append(formattedBirthPlace).append(countrySubdivisionLevel1).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof BirthPlace) == false) {
            return false;
        }
        BirthPlace rhs = ((BirthPlace) other);
        return new EqualsBuilder().append(cityName, rhs.cityName).append(countryCode, rhs.countryCode).append(postalCode, rhs.postalCode).append(formattedBirthPlace, rhs.formattedBirthPlace).append(countrySubdivisionLevel1, rhs.countrySubdivisionLevel1).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
