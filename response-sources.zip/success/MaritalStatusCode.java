
package success;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "effectiveDate",
    "codeValue",
    "shortName"
})
public class MaritalStatusCode implements Serializable
{

    @JsonProperty("effectiveDate")
    private String effectiveDate;
    @JsonProperty("codeValue")
    private String codeValue;
    @JsonProperty("shortName")
    private String shortName;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();
    private final static long serialVersionUID = 2694756265675101064L;

    @JsonProperty("effectiveDate")
    public String getEffectiveDate() {
        return effectiveDate;
    }

    @JsonProperty("effectiveDate")
    public void setEffectiveDate(String effectiveDate) {
        this.effectiveDate = effectiveDate;
    }

    @JsonProperty("codeValue")
    public String getCodeValue() {
        return codeValue;
    }

    @JsonProperty("codeValue")
    public void setCodeValue(String codeValue) {
        this.codeValue = codeValue;
    }

    @JsonProperty("shortName")
    public String getShortName() {
        return shortName;
    }

    @JsonProperty("shortName")
    public void setShortName(String shortName) {
        this.shortName = shortName;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("effectiveDate", effectiveDate).append("codeValue", codeValue).append("shortName", shortName).append("additionalProperties", additionalProperties).toString();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(additionalProperties).append(shortName).append(effectiveDate).append(codeValue).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof MaritalStatusCode) == false) {
            return false;
        }
        MaritalStatusCode rhs = ((MaritalStatusCode) other);
        return new EqualsBuilder().append(additionalProperties, rhs.additionalProperties).append(shortName, rhs.shortName).append(effectiveDate, rhs.effectiveDate).append(codeValue, rhs.codeValue).isEquals();
    }

}
