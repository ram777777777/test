
package success;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "wageLawNameCode",
    "coverageCode"
})
public class WageLawCoverage implements Serializable
{

    @JsonProperty("wageLawNameCode")
    private WageLawNameCode wageLawNameCode;
    @JsonProperty("coverageCode")
    private CoverageCode coverageCode;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();
    private final static long serialVersionUID = 1481439675554443320L;

    @JsonProperty("wageLawNameCode")
    public WageLawNameCode getWageLawNameCode() {
        return wageLawNameCode;
    }

    @JsonProperty("wageLawNameCode")
    public void setWageLawNameCode(WageLawNameCode wageLawNameCode) {
        this.wageLawNameCode = wageLawNameCode;
    }

    @JsonProperty("coverageCode")
    public CoverageCode getCoverageCode() {
        return coverageCode;
    }

    @JsonProperty("coverageCode")
    public void setCoverageCode(CoverageCode coverageCode) {
        this.coverageCode = coverageCode;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("wageLawNameCode", wageLawNameCode).append("coverageCode", coverageCode).append("additionalProperties", additionalProperties).toString();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(additionalProperties).append(coverageCode).append(wageLawNameCode).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof WageLawCoverage) == false) {
            return false;
        }
        WageLawCoverage rhs = ((WageLawCoverage) other);
        return new EqualsBuilder().append(additionalProperties, rhs.additionalProperties).append(coverageCode, rhs.coverageCode).append(wageLawNameCode, rhs.wageLawNameCode).isEquals();
    }

}
