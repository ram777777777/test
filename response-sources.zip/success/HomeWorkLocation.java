
package success;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "address",
    "nameCode"
})
public class HomeWorkLocation implements Serializable
{

    @JsonProperty("address")
    private Address___ address;
    @JsonProperty("nameCode")
    private NameCode_______________ nameCode;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();
    private final static long serialVersionUID = -8740745175007790306L;

    @JsonProperty("address")
    public Address___ getAddress() {
        return address;
    }

    @JsonProperty("address")
    public void setAddress(Address___ address) {
        this.address = address;
    }

    @JsonProperty("nameCode")
    public NameCode_______________ getNameCode() {
        return nameCode;
    }

    @JsonProperty("nameCode")
    public void setNameCode(NameCode_______________ nameCode) {
        this.nameCode = nameCode;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("address", address).append("nameCode", nameCode).append("additionalProperties", additionalProperties).toString();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(address).append(additionalProperties).append(nameCode).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof HomeWorkLocation) == false) {
            return false;
        }
        HomeWorkLocation rhs = ((HomeWorkLocation) other);
        return new EqualsBuilder().append(address, rhs.address).append(additionalProperties, rhs.additionalProperties).append(nameCode, rhs.nameCode).isEquals();
    }

}
