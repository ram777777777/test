
package success;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "monthlyRateAmount",
    "annualRateAmount",
    "payPeriodRateAmount",
    "commissionRatePercentage"
})
public class BaseRemuneration implements Serializable
{

    @JsonProperty("monthlyRateAmount")
    private MonthlyRateAmount monthlyRateAmount;
    @JsonProperty("annualRateAmount")
    private AnnualRateAmount annualRateAmount;
    @JsonProperty("payPeriodRateAmount")
    private PayPeriodRateAmount payPeriodRateAmount;
    @JsonProperty("commissionRatePercentage")
    private CommissionRatePercentage commissionRatePercentage;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();
    private final static long serialVersionUID = 5989162059609002174L;

    @JsonProperty("monthlyRateAmount")
    public MonthlyRateAmount getMonthlyRateAmount() {
        return monthlyRateAmount;
    }

    @JsonProperty("monthlyRateAmount")
    public void setMonthlyRateAmount(MonthlyRateAmount monthlyRateAmount) {
        this.monthlyRateAmount = monthlyRateAmount;
    }

    @JsonProperty("annualRateAmount")
    public AnnualRateAmount getAnnualRateAmount() {
        return annualRateAmount;
    }

    @JsonProperty("annualRateAmount")
    public void setAnnualRateAmount(AnnualRateAmount annualRateAmount) {
        this.annualRateAmount = annualRateAmount;
    }

    @JsonProperty("payPeriodRateAmount")
    public PayPeriodRateAmount getPayPeriodRateAmount() {
        return payPeriodRateAmount;
    }

    @JsonProperty("payPeriodRateAmount")
    public void setPayPeriodRateAmount(PayPeriodRateAmount payPeriodRateAmount) {
        this.payPeriodRateAmount = payPeriodRateAmount;
    }

    @JsonProperty("commissionRatePercentage")
    public CommissionRatePercentage getCommissionRatePercentage() {
        return commissionRatePercentage;
    }

    @JsonProperty("commissionRatePercentage")
    public void setCommissionRatePercentage(CommissionRatePercentage commissionRatePercentage) {
        this.commissionRatePercentage = commissionRatePercentage;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("monthlyRateAmount", monthlyRateAmount).append("annualRateAmount", annualRateAmount).append("payPeriodRateAmount", payPeriodRateAmount).append("commissionRatePercentage", commissionRatePercentage).append("additionalProperties", additionalProperties).toString();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(annualRateAmount).append(payPeriodRateAmount).append(commissionRatePercentage).append(monthlyRateAmount).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof BaseRemuneration) == false) {
            return false;
        }
        BaseRemuneration rhs = ((BaseRemuneration) other);
        return new EqualsBuilder().append(annualRateAmount, rhs.annualRateAmount).append(payPeriodRateAmount, rhs.payPeriodRateAmount).append(commissionRatePercentage, rhs.commissionRatePercentage).append(monthlyRateAmount, rhs.monthlyRateAmount).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
