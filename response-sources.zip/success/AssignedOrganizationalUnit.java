
package success;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "itemID",
    "nameCode",
    "typeCode"
})
public class AssignedOrganizationalUnit implements Serializable
{

    @JsonProperty("itemID")
    private String itemID;
    @JsonProperty("nameCode")
    private NameCode______________ nameCode;
    @JsonProperty("typeCode")
    private TypeCode_____ typeCode;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();
    private final static long serialVersionUID = -9186663741427139470L;

    @JsonProperty("itemID")
    public String getItemID() {
        return itemID;
    }

    @JsonProperty("itemID")
    public void setItemID(String itemID) {
        this.itemID = itemID;
    }

    @JsonProperty("nameCode")
    public NameCode______________ getNameCode() {
        return nameCode;
    }

    @JsonProperty("nameCode")
    public void setNameCode(NameCode______________ nameCode) {
        this.nameCode = nameCode;
    }

    @JsonProperty("typeCode")
    public TypeCode_____ getTypeCode() {
        return typeCode;
    }

    @JsonProperty("typeCode")
    public void setTypeCode(TypeCode_____ typeCode) {
        this.typeCode = typeCode;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("itemID", itemID).append("nameCode", nameCode).append("typeCode", typeCode).append("additionalProperties", additionalProperties).toString();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(itemID).append(additionalProperties).append(nameCode).append(typeCode).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof AssignedOrganizationalUnit) == false) {
            return false;
        }
        AssignedOrganizationalUnit rhs = ((AssignedOrganizationalUnit) other);
        return new EqualsBuilder().append(itemID, rhs.itemID).append(additionalProperties, rhs.additionalProperties).append(nameCode, rhs.nameCode).append(typeCode, rhs.typeCode).isEquals();
    }

}
