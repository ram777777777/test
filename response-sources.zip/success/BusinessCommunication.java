
package success;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "landlines",
    "mobiles",
    "faxes",
    "emails",
    "internetAddresses",
    "instantMessages"
})
public class BusinessCommunication implements Serializable
{

    @JsonProperty("landlines")
    private List<Landline_> landlines = null;
    @JsonProperty("mobiles")
    private List<Mobile_> mobiles = null;
    @JsonProperty("faxes")
    private List<Faxis> faxes = null;
    @JsonProperty("emails")
    private List<Email_> emails = null;
    @JsonProperty("internetAddresses")
    private List<InternetAddress> internetAddresses = null;
    @JsonProperty("instantMessages")
    private List<InstantMessage> instantMessages = null;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();
    private final static long serialVersionUID = -5482928733815704112L;

    @JsonProperty("landlines")
    public List<Landline_> getLandlines() {
        return landlines;
    }

    @JsonProperty("landlines")
    public void setLandlines(List<Landline_> landlines) {
        this.landlines = landlines;
    }

    @JsonProperty("mobiles")
    public List<Mobile_> getMobiles() {
        return mobiles;
    }

    @JsonProperty("mobiles")
    public void setMobiles(List<Mobile_> mobiles) {
        this.mobiles = mobiles;
    }

    @JsonProperty("faxes")
    public List<Faxis> getFaxes() {
        return faxes;
    }

    @JsonProperty("faxes")
    public void setFaxes(List<Faxis> faxes) {
        this.faxes = faxes;
    }

    @JsonProperty("emails")
    public List<Email_> getEmails() {
        return emails;
    }

    @JsonProperty("emails")
    public void setEmails(List<Email_> emails) {
        this.emails = emails;
    }

    @JsonProperty("internetAddresses")
    public List<InternetAddress> getInternetAddresses() {
        return internetAddresses;
    }

    @JsonProperty("internetAddresses")
    public void setInternetAddresses(List<InternetAddress> internetAddresses) {
        this.internetAddresses = internetAddresses;
    }

    @JsonProperty("instantMessages")
    public List<InstantMessage> getInstantMessages() {
        return instantMessages;
    }

    @JsonProperty("instantMessages")
    public void setInstantMessages(List<InstantMessage> instantMessages) {
        this.instantMessages = instantMessages;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("landlines", landlines).append("mobiles", mobiles).append("faxes", faxes).append("emails", emails).append("internetAddresses", internetAddresses).append("instantMessages", instantMessages).append("additionalProperties", additionalProperties).toString();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(faxes).append(emails).append(landlines).append(instantMessages).append(mobiles).append(internetAddresses).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof BusinessCommunication) == false) {
            return false;
        }
        BusinessCommunication rhs = ((BusinessCommunication) other);
        return new EqualsBuilder().append(faxes, rhs.faxes).append(emails, rhs.emails).append(landlines, rhs.landlines).append(instantMessages, rhs.instantMessages).append(mobiles, rhs.mobiles).append(internetAddresses, rhs.internetAddresses).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
