
package success;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "birthDate",
    "genderCode",
    "maritalStatusCode",
    "socialInsurancePrograms",
    "immigrationDocuments",
    "passports",
    "workAuthorizationDocuments",
    "preferredName",
    "formerNames",
    "birthName",
    "birthPlace",
    "otherPersonalAddresses",
    "raceCode",
    "citizenshipCountryCodes",
    "residencyCountryCodes",
    "militaryStatusCode",
    "militaryClassificationCodes",
    "governmentIDs",
    "legalName",
    "legalAddress",
    "communication"
})
public class Person implements Serializable
{

    @JsonProperty("birthDate")
    private String birthDate;
    @JsonProperty("genderCode")
    private GenderCode genderCode;
    @JsonProperty("maritalStatusCode")
    private MaritalStatusCode maritalStatusCode;
    @JsonProperty("socialInsurancePrograms")
    private List<SocialInsuranceProgram> socialInsurancePrograms = null;
    @JsonProperty("immigrationDocuments")
    private List<ImmigrationDocument> immigrationDocuments = null;
    @JsonProperty("passports")
    private List<Passport> passports = null;
    @JsonProperty("workAuthorizationDocuments")
    private List<WorkAuthorizationDocument> workAuthorizationDocuments = null;
    @JsonProperty("preferredName")
    private PreferredName preferredName;
    @JsonProperty("formerNames")
    private List<FormerName> formerNames = null;
    @JsonProperty("birthName")
    private BirthName birthName;
    @JsonProperty("birthPlace")
    private BirthPlace birthPlace;
    @JsonProperty("otherPersonalAddresses")
    private List<OtherPersonalAddress> otherPersonalAddresses = null;
    @JsonProperty("raceCode")
    private RaceCode raceCode;
    @JsonProperty("citizenshipCountryCodes")
    private List<CitizenshipCountryCode> citizenshipCountryCodes = null;
    @JsonProperty("residencyCountryCodes")
    private List<ResidencyCountryCode> residencyCountryCodes = null;
    @JsonProperty("militaryStatusCode")
    private MilitaryStatusCode militaryStatusCode;
    @JsonProperty("militaryClassificationCodes")
    private List<MilitaryClassificationCode> militaryClassificationCodes = null;
    @JsonProperty("governmentIDs")
    private List<GovernmentID> governmentIDs = null;
    @JsonProperty("legalName")
    private LegalName legalName;
    @JsonProperty("legalAddress")
    private LegalAddress legalAddress;
    @JsonProperty("communication")
    private Communication communication;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();
    private final static long serialVersionUID = 3736150285095443368L;

    @JsonProperty("birthDate")
    public String getBirthDate() {
        return birthDate;
    }

    @JsonProperty("birthDate")
    public void setBirthDate(String birthDate) {
        this.birthDate = birthDate;
    }

    @JsonProperty("genderCode")
    public GenderCode getGenderCode() {
        return genderCode;
    }

    @JsonProperty("genderCode")
    public void setGenderCode(GenderCode genderCode) {
        this.genderCode = genderCode;
    }

    @JsonProperty("maritalStatusCode")
    public MaritalStatusCode getMaritalStatusCode() {
        return maritalStatusCode;
    }

    @JsonProperty("maritalStatusCode")
    public void setMaritalStatusCode(MaritalStatusCode maritalStatusCode) {
        this.maritalStatusCode = maritalStatusCode;
    }

    @JsonProperty("socialInsurancePrograms")
    public List<SocialInsuranceProgram> getSocialInsurancePrograms() {
        return socialInsurancePrograms;
    }

    @JsonProperty("socialInsurancePrograms")
    public void setSocialInsurancePrograms(List<SocialInsuranceProgram> socialInsurancePrograms) {
        this.socialInsurancePrograms = socialInsurancePrograms;
    }

    @JsonProperty("immigrationDocuments")
    public List<ImmigrationDocument> getImmigrationDocuments() {
        return immigrationDocuments;
    }

    @JsonProperty("immigrationDocuments")
    public void setImmigrationDocuments(List<ImmigrationDocument> immigrationDocuments) {
        this.immigrationDocuments = immigrationDocuments;
    }

    @JsonProperty("passports")
    public List<Passport> getPassports() {
        return passports;
    }

    @JsonProperty("passports")
    public void setPassports(List<Passport> passports) {
        this.passports = passports;
    }

    @JsonProperty("workAuthorizationDocuments")
    public List<WorkAuthorizationDocument> getWorkAuthorizationDocuments() {
        return workAuthorizationDocuments;
    }

    @JsonProperty("workAuthorizationDocuments")
    public void setWorkAuthorizationDocuments(List<WorkAuthorizationDocument> workAuthorizationDocuments) {
        this.workAuthorizationDocuments = workAuthorizationDocuments;
    }

    @JsonProperty("preferredName")
    public PreferredName getPreferredName() {
        return preferredName;
    }

    @JsonProperty("preferredName")
    public void setPreferredName(PreferredName preferredName) {
        this.preferredName = preferredName;
    }

    @JsonProperty("formerNames")
    public List<FormerName> getFormerNames() {
        return formerNames;
    }

    @JsonProperty("formerNames")
    public void setFormerNames(List<FormerName> formerNames) {
        this.formerNames = formerNames;
    }

    @JsonProperty("birthName")
    public BirthName getBirthName() {
        return birthName;
    }

    @JsonProperty("birthName")
    public void setBirthName(BirthName birthName) {
        this.birthName = birthName;
    }

    @JsonProperty("birthPlace")
    public BirthPlace getBirthPlace() {
        return birthPlace;
    }

    @JsonProperty("birthPlace")
    public void setBirthPlace(BirthPlace birthPlace) {
        this.birthPlace = birthPlace;
    }

    @JsonProperty("otherPersonalAddresses")
    public List<OtherPersonalAddress> getOtherPersonalAddresses() {
        return otherPersonalAddresses;
    }

    @JsonProperty("otherPersonalAddresses")
    public void setOtherPersonalAddresses(List<OtherPersonalAddress> otherPersonalAddresses) {
        this.otherPersonalAddresses = otherPersonalAddresses;
    }

    @JsonProperty("raceCode")
    public RaceCode getRaceCode() {
        return raceCode;
    }

    @JsonProperty("raceCode")
    public void setRaceCode(RaceCode raceCode) {
        this.raceCode = raceCode;
    }

    @JsonProperty("citizenshipCountryCodes")
    public List<CitizenshipCountryCode> getCitizenshipCountryCodes() {
        return citizenshipCountryCodes;
    }

    @JsonProperty("citizenshipCountryCodes")
    public void setCitizenshipCountryCodes(List<CitizenshipCountryCode> citizenshipCountryCodes) {
        this.citizenshipCountryCodes = citizenshipCountryCodes;
    }

    @JsonProperty("residencyCountryCodes")
    public List<ResidencyCountryCode> getResidencyCountryCodes() {
        return residencyCountryCodes;
    }

    @JsonProperty("residencyCountryCodes")
    public void setResidencyCountryCodes(List<ResidencyCountryCode> residencyCountryCodes) {
        this.residencyCountryCodes = residencyCountryCodes;
    }

    @JsonProperty("militaryStatusCode")
    public MilitaryStatusCode getMilitaryStatusCode() {
        return militaryStatusCode;
    }

    @JsonProperty("militaryStatusCode")
    public void setMilitaryStatusCode(MilitaryStatusCode militaryStatusCode) {
        this.militaryStatusCode = militaryStatusCode;
    }

    @JsonProperty("militaryClassificationCodes")
    public List<MilitaryClassificationCode> getMilitaryClassificationCodes() {
        return militaryClassificationCodes;
    }

    @JsonProperty("militaryClassificationCodes")
    public void setMilitaryClassificationCodes(List<MilitaryClassificationCode> militaryClassificationCodes) {
        this.militaryClassificationCodes = militaryClassificationCodes;
    }

    @JsonProperty("governmentIDs")
    public List<GovernmentID> getGovernmentIDs() {
        return governmentIDs;
    }

    @JsonProperty("governmentIDs")
    public void setGovernmentIDs(List<GovernmentID> governmentIDs) {
        this.governmentIDs = governmentIDs;
    }

    @JsonProperty("legalName")
    public LegalName getLegalName() {
        return legalName;
    }

    @JsonProperty("legalName")
    public void setLegalName(LegalName legalName) {
        this.legalName = legalName;
    }

    @JsonProperty("legalAddress")
    public LegalAddress getLegalAddress() {
        return legalAddress;
    }

    @JsonProperty("legalAddress")
    public void setLegalAddress(LegalAddress legalAddress) {
        this.legalAddress = legalAddress;
    }

    @JsonProperty("communication")
    public Communication getCommunication() {
        return communication;
    }

    @JsonProperty("communication")
    public void setCommunication(Communication communication) {
        this.communication = communication;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("birthDate", birthDate).append("genderCode", genderCode).append("maritalStatusCode", maritalStatusCode).append("socialInsurancePrograms", socialInsurancePrograms).append("immigrationDocuments", immigrationDocuments).append("passports", passports).append("workAuthorizationDocuments", workAuthorizationDocuments).append("preferredName", preferredName).append("formerNames", formerNames).append("birthName", birthName).append("birthPlace", birthPlace).append("otherPersonalAddresses", otherPersonalAddresses).append("raceCode", raceCode).append("citizenshipCountryCodes", citizenshipCountryCodes).append("residencyCountryCodes", residencyCountryCodes).append("militaryStatusCode", militaryStatusCode).append("militaryClassificationCodes", militaryClassificationCodes).append("governmentIDs", governmentIDs).append("legalName", legalName).append("legalAddress", legalAddress).append("communication", communication).append("additionalProperties", additionalProperties).toString();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(citizenshipCountryCodes).append(immigrationDocuments).append(governmentIDs).append(socialInsurancePrograms).append(passports).append(birthDate).append(birthName).append(legalAddress).append(residencyCountryCodes).append(militaryClassificationCodes).append(formerNames).append(militaryStatusCode).append(legalName).append(maritalStatusCode).append(birthPlace).append(genderCode).append(workAuthorizationDocuments).append(preferredName).append(additionalProperties).append(communication).append(otherPersonalAddresses).append(raceCode).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof Person) == false) {
            return false;
        }
        Person rhs = ((Person) other);
        return new EqualsBuilder().append(citizenshipCountryCodes, rhs.citizenshipCountryCodes).append(immigrationDocuments, rhs.immigrationDocuments).append(governmentIDs, rhs.governmentIDs).append(socialInsurancePrograms, rhs.socialInsurancePrograms).append(passports, rhs.passports).append(birthDate, rhs.birthDate).append(birthName, rhs.birthName).append(legalAddress, rhs.legalAddress).append(residencyCountryCodes, rhs.residencyCountryCodes).append(militaryClassificationCodes, rhs.militaryClassificationCodes).append(formerNames, rhs.formerNames).append(militaryStatusCode, rhs.militaryStatusCode).append(legalName, rhs.legalName).append(maritalStatusCode, rhs.maritalStatusCode).append(birthPlace, rhs.birthPlace).append(genderCode, rhs.genderCode).append(workAuthorizationDocuments, rhs.workAuthorizationDocuments).append(preferredName, rhs.preferredName).append(additionalProperties, rhs.additionalProperties).append(communication, rhs.communication).append(otherPersonalAddresses, rhs.otherPersonalAddresses).append(raceCode, rhs.raceCode).isEquals();
    }

}
