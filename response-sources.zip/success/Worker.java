
package success;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "associateOID",
    "workerID",
    "person",
    "workerDates",
    "workerStatus",
    "photos",
    "businessCommunication",
    "workAssignments",
    "links"
})
public class Worker implements Serializable
{

    @JsonProperty("associateOID")
    private String associateOID;
    @JsonProperty("workerID")
    private WorkerID workerID;
    @JsonProperty("person")
    private Person person;
    @JsonProperty("workerDates")
    private WorkerDates workerDates;
    @JsonProperty("workerStatus")
    private WorkerStatus workerStatus;
    @JsonProperty("photos")
    private List<Photo> photos = null;
    @JsonProperty("businessCommunication")
    private BusinessCommunication businessCommunication;
    @JsonProperty("workAssignments")
    private List<WorkAssignment> workAssignments = null;
    @JsonProperty("links")
    private List<Link_> links = null;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();
    private final static long serialVersionUID = -4615805352383983807L;

    @JsonProperty("associateOID")
    public String getAssociateOID() {
        return associateOID;
    }

    @JsonProperty("associateOID")
    public void setAssociateOID(String associateOID) {
        this.associateOID = associateOID;
    }

    @JsonProperty("workerID")
    public WorkerID getWorkerID() {
        return workerID;
    }

    @JsonProperty("workerID")
    public void setWorkerID(WorkerID workerID) {
        this.workerID = workerID;
    }

    @JsonProperty("person")
    public Person getPerson() {
        return person;
    }

    @JsonProperty("person")
    public void setPerson(Person person) {
        this.person = person;
    }

    @JsonProperty("workerDates")
    public WorkerDates getWorkerDates() {
        return workerDates;
    }

    @JsonProperty("workerDates")
    public void setWorkerDates(WorkerDates workerDates) {
        this.workerDates = workerDates;
    }

    @JsonProperty("workerStatus")
    public WorkerStatus getWorkerStatus() {
        return workerStatus;
    }

    @JsonProperty("workerStatus")
    public void setWorkerStatus(WorkerStatus workerStatus) {
        this.workerStatus = workerStatus;
    }

    @JsonProperty("photos")
    public List<Photo> getPhotos() {
        return photos;
    }

    @JsonProperty("photos")
    public void setPhotos(List<Photo> photos) {
        this.photos = photos;
    }

    @JsonProperty("businessCommunication")
    public BusinessCommunication getBusinessCommunication() {
        return businessCommunication;
    }

    @JsonProperty("businessCommunication")
    public void setBusinessCommunication(BusinessCommunication businessCommunication) {
        this.businessCommunication = businessCommunication;
    }

    @JsonProperty("workAssignments")
    public List<WorkAssignment> getWorkAssignments() {
        return workAssignments;
    }

    @JsonProperty("workAssignments")
    public void setWorkAssignments(List<WorkAssignment> workAssignments) {
        this.workAssignments = workAssignments;
    }

    @JsonProperty("links")
    public List<Link_> getLinks() {
        return links;
    }

    @JsonProperty("links")
    public void setLinks(List<Link_> links) {
        this.links = links;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("associateOID", associateOID).append("workerID", workerID).append("person", person).append("workerDates", workerDates).append("workerStatus", workerStatus).append("photos", photos).append("businessCommunication", businessCommunication).append("workAssignments", workAssignments).append("links", links).append("additionalProperties", additionalProperties).toString();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(workerID).append(workAssignments).append(person).append(links).append(workerStatus).append(additionalProperties).append(associateOID).append(businessCommunication).append(photos).append(workerDates).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof Worker) == false) {
            return false;
        }
        Worker rhs = ((Worker) other);
        return new EqualsBuilder().append(workerID, rhs.workerID).append(workAssignments, rhs.workAssignments).append(person, rhs.person).append(links, rhs.links).append(workerStatus, rhs.workerStatus).append(additionalProperties, rhs.additionalProperties).append(associateOID, rhs.associateOID).append(businessCommunication, rhs.businessCommunication).append(photos, rhs.photos).append(workerDates, rhs.workerDates).isEquals();
    }

}
