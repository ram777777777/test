
package success;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "statusCode",
    "reasonCode"
})
public class AssignmentStatus implements Serializable
{

    @JsonProperty("statusCode")
    private StatusCode_ statusCode;
    @JsonProperty("reasonCode")
    private ReasonCode_ reasonCode;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();
    private final static long serialVersionUID = -4823114142334160761L;

    @JsonProperty("statusCode")
    public StatusCode_ getStatusCode() {
        return statusCode;
    }

    @JsonProperty("statusCode")
    public void setStatusCode(StatusCode_ statusCode) {
        this.statusCode = statusCode;
    }

    @JsonProperty("reasonCode")
    public ReasonCode_ getReasonCode() {
        return reasonCode;
    }

    @JsonProperty("reasonCode")
    public void setReasonCode(ReasonCode_ reasonCode) {
        this.reasonCode = reasonCode;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("statusCode", statusCode).append("reasonCode", reasonCode).append("additionalProperties", additionalProperties).toString();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(reasonCode).append(additionalProperties).append(statusCode).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof AssignmentStatus) == false) {
            return false;
        }
        AssignmentStatus rhs = ((AssignmentStatus) other);
        return new EqualsBuilder().append(reasonCode, rhs.reasonCode).append(additionalProperties, rhs.additionalProperties).append(statusCode, rhs.statusCode).isEquals();
    }

}
