
package success;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "amountValue",
    "currencyCode",
    "baseUnitCode"
})
public class MedianRate implements Serializable
{

    @JsonProperty("amountValue")
    private Integer amountValue;
    @JsonProperty("currencyCode")
    private String currencyCode;
    @JsonProperty("baseUnitCode")
    private BaseUnitCode___ baseUnitCode;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();
    private final static long serialVersionUID = 9181063739883095179L;

    @JsonProperty("amountValue")
    public Integer getAmountValue() {
        return amountValue;
    }

    @JsonProperty("amountValue")
    public void setAmountValue(Integer amountValue) {
        this.amountValue = amountValue;
    }

    @JsonProperty("currencyCode")
    public String getCurrencyCode() {
        return currencyCode;
    }

    @JsonProperty("currencyCode")
    public void setCurrencyCode(String currencyCode) {
        this.currencyCode = currencyCode;
    }

    @JsonProperty("baseUnitCode")
    public BaseUnitCode___ getBaseUnitCode() {
        return baseUnitCode;
    }

    @JsonProperty("baseUnitCode")
    public void setBaseUnitCode(BaseUnitCode___ baseUnitCode) {
        this.baseUnitCode = baseUnitCode;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("amountValue", amountValue).append("currencyCode", currencyCode).append("baseUnitCode", baseUnitCode).append("additionalProperties", additionalProperties).toString();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(amountValue).append(additionalProperties).append(currencyCode).append(baseUnitCode).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof MedianRate) == false) {
            return false;
        }
        MedianRate rhs = ((MedianRate) other);
        return new EqualsBuilder().append(amountValue, rhs.amountValue).append(additionalProperties, rhs.additionalProperties).append(currencyCode, rhs.currencyCode).append(baseUnitCode, rhs.baseUnitCode).isEquals();
    }

}
