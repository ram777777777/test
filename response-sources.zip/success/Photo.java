
package success;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "itemID",
    "nameCode",
    "links"
})
public class Photo implements Serializable
{

    @JsonProperty("itemID")
    private String itemID;
    @JsonProperty("nameCode")
    private NameCode__________ nameCode;
    @JsonProperty("links")
    private List<Link> links = null;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();
    private final static long serialVersionUID = -5389996334184400204L;

    @JsonProperty("itemID")
    public String getItemID() {
        return itemID;
    }

    @JsonProperty("itemID")
    public void setItemID(String itemID) {
        this.itemID = itemID;
    }

    @JsonProperty("nameCode")
    public NameCode__________ getNameCode() {
        return nameCode;
    }

    @JsonProperty("nameCode")
    public void setNameCode(NameCode__________ nameCode) {
        this.nameCode = nameCode;
    }

    @JsonProperty("links")
    public List<Link> getLinks() {
        return links;
    }

    @JsonProperty("links")
    public void setLinks(List<Link> links) {
        this.links = links;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("itemID", itemID).append("nameCode", nameCode).append("links", links).append("additionalProperties", additionalProperties).toString();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(itemID).append(links).append(additionalProperties).append(nameCode).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof Photo) == false) {
            return false;
        }
        Photo rhs = ((Photo) other);
        return new EqualsBuilder().append(itemID, rhs.itemID).append(links, rhs.links).append(additionalProperties, rhs.additionalProperties).append(nameCode, rhs.nameCode).isEquals();
    }

}
