
package success;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "itemID",
    "typeCode",
    "intervalCode",
    "nameCode",
    "rate"
})
public class AdditionalRemuneration implements Serializable
{

    @JsonProperty("itemID")
    private String itemID;
    @JsonProperty("typeCode")
    private TypeCode______ typeCode;
    @JsonProperty("intervalCode")
    private IntervalCode intervalCode;
    @JsonProperty("nameCode")
    private NameCode_________________ nameCode;
    @JsonProperty("rate")
    private Rate rate;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();
    private final static long serialVersionUID = 2395327242685723612L;

    @JsonProperty("itemID")
    public String getItemID() {
        return itemID;
    }

    @JsonProperty("itemID")
    public void setItemID(String itemID) {
        this.itemID = itemID;
    }

    @JsonProperty("typeCode")
    public TypeCode______ getTypeCode() {
        return typeCode;
    }

    @JsonProperty("typeCode")
    public void setTypeCode(TypeCode______ typeCode) {
        this.typeCode = typeCode;
    }

    @JsonProperty("intervalCode")
    public IntervalCode getIntervalCode() {
        return intervalCode;
    }

    @JsonProperty("intervalCode")
    public void setIntervalCode(IntervalCode intervalCode) {
        this.intervalCode = intervalCode;
    }

    @JsonProperty("nameCode")
    public NameCode_________________ getNameCode() {
        return nameCode;
    }

    @JsonProperty("nameCode")
    public void setNameCode(NameCode_________________ nameCode) {
        this.nameCode = nameCode;
    }

    @JsonProperty("rate")
    public Rate getRate() {
        return rate;
    }

    @JsonProperty("rate")
    public void setRate(Rate rate) {
        this.rate = rate;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("itemID", itemID).append("typeCode", typeCode).append("intervalCode", intervalCode).append("nameCode", nameCode).append("rate", rate).append("additionalProperties", additionalProperties).toString();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(itemID).append(intervalCode).append(nameCode).append(rate).append(additionalProperties).append(typeCode).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof AdditionalRemuneration) == false) {
            return false;
        }
        AdditionalRemuneration rhs = ((AdditionalRemuneration) other);
        return new EqualsBuilder().append(itemID, rhs.itemID).append(intervalCode, rhs.intervalCode).append(nameCode, rhs.nameCode).append(rate, rhs.rate).append(additionalProperties, rhs.additionalProperties).append(typeCode, rhs.typeCode).isEquals();
    }

}
