
package success;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "minimumRate",
    "medianRate",
    "maximumRate"
})
public class PayGradePayRange implements Serializable
{

    @JsonProperty("minimumRate")
    private MinimumRate minimumRate;
    @JsonProperty("medianRate")
    private MedianRate medianRate;
    @JsonProperty("maximumRate")
    private MaximumRate maximumRate;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();
    private final static long serialVersionUID = 16816153744626684L;

    @JsonProperty("minimumRate")
    public MinimumRate getMinimumRate() {
        return minimumRate;
    }

    @JsonProperty("minimumRate")
    public void setMinimumRate(MinimumRate minimumRate) {
        this.minimumRate = minimumRate;
    }

    @JsonProperty("medianRate")
    public MedianRate getMedianRate() {
        return medianRate;
    }

    @JsonProperty("medianRate")
    public void setMedianRate(MedianRate medianRate) {
        this.medianRate = medianRate;
    }

    @JsonProperty("maximumRate")
    public MaximumRate getMaximumRate() {
        return maximumRate;
    }

    @JsonProperty("maximumRate")
    public void setMaximumRate(MaximumRate maximumRate) {
        this.maximumRate = maximumRate;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("minimumRate", minimumRate).append("medianRate", medianRate).append("maximumRate", maximumRate).append("additionalProperties", additionalProperties).toString();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(maximumRate).append(minimumRate).append(medianRate).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof PayGradePayRange) == false) {
            return false;
        }
        PayGradePayRange rhs = ((PayGradePayRange) other);
        return new EqualsBuilder().append(maximumRate, rhs.maximumRate).append(minimumRate, rhs.minimumRate).append(medianRate, rhs.medianRate).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
