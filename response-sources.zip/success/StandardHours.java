
package success;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "hoursQuantity",
    "unitCode"
})
public class StandardHours implements Serializable
{

    @JsonProperty("hoursQuantity")
    private Integer hoursQuantity;
    @JsonProperty("unitCode")
    private UnitCode unitCode;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();
    private final static long serialVersionUID = -4818574763176012217L;

    @JsonProperty("hoursQuantity")
    public Integer getHoursQuantity() {
        return hoursQuantity;
    }

    @JsonProperty("hoursQuantity")
    public void setHoursQuantity(Integer hoursQuantity) {
        this.hoursQuantity = hoursQuantity;
    }

    @JsonProperty("unitCode")
    public UnitCode getUnitCode() {
        return unitCode;
    }

    @JsonProperty("unitCode")
    public void setUnitCode(UnitCode unitCode) {
        this.unitCode = unitCode;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("hoursQuantity", hoursQuantity).append("unitCode", unitCode).append("additionalProperties", additionalProperties).toString();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(additionalProperties).append(hoursQuantity).append(unitCode).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof StandardHours) == false) {
            return false;
        }
        StandardHours rhs = ((StandardHours) other);
        return new EqualsBuilder().append(additionalProperties, rhs.additionalProperties).append(hoursQuantity, rhs.hoursQuantity).append(unitCode, rhs.unitCode).isEquals();
    }

}
