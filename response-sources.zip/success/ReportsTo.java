
package success;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "itemID",
    "positionID",
    "associateOID",
    "workerID",
    "reportsToWorkerName",
    "reportsToRelationshipCode"
})
public class ReportsTo implements Serializable
{

    @JsonProperty("itemID")
    private String itemID;
    @JsonProperty("positionID")
    private String positionID;
    @JsonProperty("associateOID")
    private String associateOID;
    @JsonProperty("workerID")
    private WorkerID_ workerID;
    @JsonProperty("reportsToWorkerName")
    private ReportsToWorkerName reportsToWorkerName;
    @JsonProperty("reportsToRelationshipCode")
    private ReportsToRelationshipCode reportsToRelationshipCode;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();
    private final static long serialVersionUID = -8002091824743105652L;

    @JsonProperty("itemID")
    public String getItemID() {
        return itemID;
    }

    @JsonProperty("itemID")
    public void setItemID(String itemID) {
        this.itemID = itemID;
    }

    @JsonProperty("positionID")
    public String getPositionID() {
        return positionID;
    }

    @JsonProperty("positionID")
    public void setPositionID(String positionID) {
        this.positionID = positionID;
    }

    @JsonProperty("associateOID")
    public String getAssociateOID() {
        return associateOID;
    }

    @JsonProperty("associateOID")
    public void setAssociateOID(String associateOID) {
        this.associateOID = associateOID;
    }

    @JsonProperty("workerID")
    public WorkerID_ getWorkerID() {
        return workerID;
    }

    @JsonProperty("workerID")
    public void setWorkerID(WorkerID_ workerID) {
        this.workerID = workerID;
    }

    @JsonProperty("reportsToWorkerName")
    public ReportsToWorkerName getReportsToWorkerName() {
        return reportsToWorkerName;
    }

    @JsonProperty("reportsToWorkerName")
    public void setReportsToWorkerName(ReportsToWorkerName reportsToWorkerName) {
        this.reportsToWorkerName = reportsToWorkerName;
    }

    @JsonProperty("reportsToRelationshipCode")
    public ReportsToRelationshipCode getReportsToRelationshipCode() {
        return reportsToRelationshipCode;
    }

    @JsonProperty("reportsToRelationshipCode")
    public void setReportsToRelationshipCode(ReportsToRelationshipCode reportsToRelationshipCode) {
        this.reportsToRelationshipCode = reportsToRelationshipCode;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("itemID", itemID).append("positionID", positionID).append("associateOID", associateOID).append("workerID", workerID).append("reportsToWorkerName", reportsToWorkerName).append("reportsToRelationshipCode", reportsToRelationshipCode).append("additionalProperties", additionalProperties).toString();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(itemID).append(workerID).append(positionID).append(reportsToWorkerName).append(additionalProperties).append(associateOID).append(reportsToRelationshipCode).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof ReportsTo) == false) {
            return false;
        }
        ReportsTo rhs = ((ReportsTo) other);
        return new EqualsBuilder().append(itemID, rhs.itemID).append(workerID, rhs.workerID).append(positionID, rhs.positionID).append(reportsToWorkerName, rhs.reportsToWorkerName).append(additionalProperties, rhs.additionalProperties).append(associateOID, rhs.associateOID).append(reportsToRelationshipCode, rhs.reportsToRelationshipCode).isEquals();
    }

}
