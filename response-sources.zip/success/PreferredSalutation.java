
package success;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "salutationCode",
    "typeCode",
    "sequenceNumber"
})
public class PreferredSalutation implements Serializable
{

    @JsonProperty("salutationCode")
    private SalutationCode salutationCode;
    @JsonProperty("typeCode")
    private TypeCode___ typeCode;
    @JsonProperty("sequenceNumber")
    private Integer sequenceNumber;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();
    private final static long serialVersionUID = -8768952629548460757L;

    @JsonProperty("salutationCode")
    public SalutationCode getSalutationCode() {
        return salutationCode;
    }

    @JsonProperty("salutationCode")
    public void setSalutationCode(SalutationCode salutationCode) {
        this.salutationCode = salutationCode;
    }

    @JsonProperty("typeCode")
    public TypeCode___ getTypeCode() {
        return typeCode;
    }

    @JsonProperty("typeCode")
    public void setTypeCode(TypeCode___ typeCode) {
        this.typeCode = typeCode;
    }

    @JsonProperty("sequenceNumber")
    public Integer getSequenceNumber() {
        return sequenceNumber;
    }

    @JsonProperty("sequenceNumber")
    public void setSequenceNumber(Integer sequenceNumber) {
        this.sequenceNumber = sequenceNumber;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("salutationCode", salutationCode).append("typeCode", typeCode).append("sequenceNumber", sequenceNumber).append("additionalProperties", additionalProperties).toString();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(sequenceNumber).append(additionalProperties).append(salutationCode).append(typeCode).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof PreferredSalutation) == false) {
            return false;
        }
        PreferredSalutation rhs = ((PreferredSalutation) other);
        return new EqualsBuilder().append(sequenceNumber, rhs.sequenceNumber).append(additionalProperties, rhs.additionalProperties).append(salutationCode, rhs.salutationCode).append(typeCode, rhs.typeCode).isEquals();
    }

}
