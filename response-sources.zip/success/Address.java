
package success;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "lineOne",
    "cityName",
    "countrySubdivisionLevel1",
    "countryCode",
    "postalCode"
})
public class Address implements Serializable
{

    @JsonProperty("lineOne")
    private String lineOne;
    @JsonProperty("cityName")
    private String cityName;
    @JsonProperty("countrySubdivisionLevel1")
    private CountrySubdivisionLevel1 countrySubdivisionLevel1;
    @JsonProperty("countryCode")
    private String countryCode;
    @JsonProperty("postalCode")
    private String postalCode;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();
    private final static long serialVersionUID = -4632813562002310860L;

    @JsonProperty("lineOne")
    public String getLineOne() {
        return lineOne;
    }

    @JsonProperty("lineOne")
    public void setLineOne(String lineOne) {
        this.lineOne = lineOne;
    }

    @JsonProperty("cityName")
    public String getCityName() {
        return cityName;
    }

    @JsonProperty("cityName")
    public void setCityName(String cityName) {
        this.cityName = cityName;
    }

    @JsonProperty("countrySubdivisionLevel1")
    public CountrySubdivisionLevel1 getCountrySubdivisionLevel1() {
        return countrySubdivisionLevel1;
    }

    @JsonProperty("countrySubdivisionLevel1")
    public void setCountrySubdivisionLevel1(CountrySubdivisionLevel1 countrySubdivisionLevel1) {
        this.countrySubdivisionLevel1 = countrySubdivisionLevel1;
    }

    @JsonProperty("countryCode")
    public String getCountryCode() {
        return countryCode;
    }

    @JsonProperty("countryCode")
    public void setCountryCode(String countryCode) {
        this.countryCode = countryCode;
    }

    @JsonProperty("postalCode")
    public String getPostalCode() {
        return postalCode;
    }

    @JsonProperty("postalCode")
    public void setPostalCode(String postalCode) {
        this.postalCode = postalCode;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("lineOne", lineOne).append("cityName", cityName).append("countrySubdivisionLevel1", countrySubdivisionLevel1).append("countryCode", countryCode).append("postalCode", postalCode).append("additionalProperties", additionalProperties).toString();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(cityName).append(countryCode).append(postalCode).append(lineOne).append(countrySubdivisionLevel1).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof Address) == false) {
            return false;
        }
        Address rhs = ((Address) other);
        return new EqualsBuilder().append(cityName, rhs.cityName).append(countryCode, rhs.countryCode).append(postalCode, rhs.postalCode).append(lineOne, rhs.lineOne).append(countrySubdivisionLevel1, rhs.countrySubdivisionLevel1).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
