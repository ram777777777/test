
package success;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "landlines",
    "mobiles",
    "emails",
    "socialNetworks"
})
public class Communication implements Serializable
{

    @JsonProperty("landlines")
    private List<Landline> landlines = null;
    @JsonProperty("mobiles")
    private List<Mobile> mobiles = null;
    @JsonProperty("emails")
    private List<Email> emails = null;
    @JsonProperty("socialNetworks")
    private List<SocialNetwork> socialNetworks = null;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();
    private final static long serialVersionUID = 7815023700197849050L;

    @JsonProperty("landlines")
    public List<Landline> getLandlines() {
        return landlines;
    }

    @JsonProperty("landlines")
    public void setLandlines(List<Landline> landlines) {
        this.landlines = landlines;
    }

    @JsonProperty("mobiles")
    public List<Mobile> getMobiles() {
        return mobiles;
    }

    @JsonProperty("mobiles")
    public void setMobiles(List<Mobile> mobiles) {
        this.mobiles = mobiles;
    }

    @JsonProperty("emails")
    public List<Email> getEmails() {
        return emails;
    }

    @JsonProperty("emails")
    public void setEmails(List<Email> emails) {
        this.emails = emails;
    }

    @JsonProperty("socialNetworks")
    public List<SocialNetwork> getSocialNetworks() {
        return socialNetworks;
    }

    @JsonProperty("socialNetworks")
    public void setSocialNetworks(List<SocialNetwork> socialNetworks) {
        this.socialNetworks = socialNetworks;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("landlines", landlines).append("mobiles", mobiles).append("emails", emails).append("socialNetworks", socialNetworks).append("additionalProperties", additionalProperties).toString();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(emails).append(landlines).append(socialNetworks).append(additionalProperties).append(mobiles).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof Communication) == false) {
            return false;
        }
        Communication rhs = ((Communication) other);
        return new EqualsBuilder().append(emails, rhs.emails).append(landlines, rhs.landlines).append(socialNetworks, rhs.socialNetworks).append(additionalProperties, rhs.additionalProperties).append(mobiles, rhs.mobiles).isEquals();
    }

}
