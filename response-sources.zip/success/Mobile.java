
package success;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "itemID",
    "nameCode",
    "countryDialing",
    "areaDialing",
    "dialNumber",
    "formattedNumber"
})
public class Mobile implements Serializable
{

    @JsonProperty("itemID")
    private String itemID;
    @JsonProperty("nameCode")
    private NameCode________ nameCode;
    @JsonProperty("countryDialing")
    private String countryDialing;
    @JsonProperty("areaDialing")
    private String areaDialing;
    @JsonProperty("dialNumber")
    private String dialNumber;
    @JsonProperty("formattedNumber")
    private String formattedNumber;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();
    private final static long serialVersionUID = -1644672943378090112L;

    @JsonProperty("itemID")
    public String getItemID() {
        return itemID;
    }

    @JsonProperty("itemID")
    public void setItemID(String itemID) {
        this.itemID = itemID;
    }

    @JsonProperty("nameCode")
    public NameCode________ getNameCode() {
        return nameCode;
    }

    @JsonProperty("nameCode")
    public void setNameCode(NameCode________ nameCode) {
        this.nameCode = nameCode;
    }

    @JsonProperty("countryDialing")
    public String getCountryDialing() {
        return countryDialing;
    }

    @JsonProperty("countryDialing")
    public void setCountryDialing(String countryDialing) {
        this.countryDialing = countryDialing;
    }

    @JsonProperty("areaDialing")
    public String getAreaDialing() {
        return areaDialing;
    }

    @JsonProperty("areaDialing")
    public void setAreaDialing(String areaDialing) {
        this.areaDialing = areaDialing;
    }

    @JsonProperty("dialNumber")
    public String getDialNumber() {
        return dialNumber;
    }

    @JsonProperty("dialNumber")
    public void setDialNumber(String dialNumber) {
        this.dialNumber = dialNumber;
    }

    @JsonProperty("formattedNumber")
    public String getFormattedNumber() {
        return formattedNumber;
    }

    @JsonProperty("formattedNumber")
    public void setFormattedNumber(String formattedNumber) {
        this.formattedNumber = formattedNumber;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("itemID", itemID).append("nameCode", nameCode).append("countryDialing", countryDialing).append("areaDialing", areaDialing).append("dialNumber", dialNumber).append("formattedNumber", formattedNumber).append("additionalProperties", additionalProperties).toString();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(itemID).append(formattedNumber).append(nameCode).append(areaDialing).append(countryDialing).append(dialNumber).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof Mobile) == false) {
            return false;
        }
        Mobile rhs = ((Mobile) other);
        return new EqualsBuilder().append(itemID, rhs.itemID).append(formattedNumber, rhs.formattedNumber).append(nameCode, rhs.nameCode).append(areaDialing, rhs.areaDialing).append(countryDialing, rhs.countryDialing).append(dialNumber, rhs.dialNumber).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
