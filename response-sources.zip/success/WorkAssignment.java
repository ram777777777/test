
package success;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "primaryIndicator",
    "offerExtensionDate",
    "offerAcceptanceDate",
    "hireDate",
    "expectedStartDate",
    "actualStartDate",
    "assignmentStatus",
    "workerTypeCode",
    "assignmentTermCode",
    "workLevelCode",
    "nationalityContextCode",
    "vipIndicator",
    "executiveIndicator",
    "officerIndicator",
    "highlyCompensatedIndicator",
    "highlyCompensatedTypeCode",
    "stockOwnerIndicator",
    "stockOwnerPercentage",
    "workerGroups",
    "jobCode",
    "jobTitle",
    "occupationalClassifications",
    "wageLawCoverage",
    "workArrangementCode",
    "standardHours",
    "homeOrganizationalUnits",
    "assignedOrganizationalUnits",
    "homeWorkLocation",
    "assignedWorkLocations",
    "remunerationBasisCode",
    "payCycleCode",
    "standardPayPeriodHours",
    "baseRemuneration",
    "additionalRemunerations",
    "reportsTo",
    "payrollProcessingStatusCode",
    "payrollFileNumber",
    "payrollRegionCode",
    "payScaleCode",
    "payGradeCode",
    "payGradePayRange",
    "compaRatio"
})
public class WorkAssignment implements Serializable
{

    @JsonProperty("primaryIndicator")
    private Boolean primaryIndicator;
    @JsonProperty("offerExtensionDate")
    private String offerExtensionDate;
    @JsonProperty("offerAcceptanceDate")
    private String offerAcceptanceDate;
    @JsonProperty("hireDate")
    private String hireDate;
    @JsonProperty("expectedStartDate")
    private String expectedStartDate;
    @JsonProperty("actualStartDate")
    private String actualStartDate;
    @JsonProperty("assignmentStatus")
    private AssignmentStatus assignmentStatus;
    @JsonProperty("workerTypeCode")
    private WorkerTypeCode workerTypeCode;
    @JsonProperty("assignmentTermCode")
    private AssignmentTermCode assignmentTermCode;
    @JsonProperty("workLevelCode")
    private WorkLevelCode workLevelCode;
    @JsonProperty("nationalityContextCode")
    private NationalityContextCode nationalityContextCode;
    @JsonProperty("vipIndicator")
    private Boolean vipIndicator;
    @JsonProperty("executiveIndicator")
    private Boolean executiveIndicator;
    @JsonProperty("officerIndicator")
    private Boolean officerIndicator;
    @JsonProperty("highlyCompensatedIndicator")
    private Boolean highlyCompensatedIndicator;
    @JsonProperty("highlyCompensatedTypeCode")
    private HighlyCompensatedTypeCode highlyCompensatedTypeCode;
    @JsonProperty("stockOwnerIndicator")
    private Boolean stockOwnerIndicator;
    @JsonProperty("stockOwnerPercentage")
    private Double stockOwnerPercentage;
    @JsonProperty("workerGroups")
    private List<WorkerGroup> workerGroups = null;
    @JsonProperty("jobCode")
    private JobCode jobCode;
    @JsonProperty("jobTitle")
    private String jobTitle;
    @JsonProperty("occupationalClassifications")
    private List<OccupationalClassification> occupationalClassifications = null;
    @JsonProperty("wageLawCoverage")
    private WageLawCoverage wageLawCoverage;
    @JsonProperty("workArrangementCode")
    private WorkArrangementCode workArrangementCode;
    @JsonProperty("standardHours")
    private StandardHours standardHours;
    @JsonProperty("homeOrganizationalUnits")
    private List<HomeOrganizationalUnit> homeOrganizationalUnits = null;
    @JsonProperty("assignedOrganizationalUnits")
    private List<AssignedOrganizationalUnit> assignedOrganizationalUnits = null;
    @JsonProperty("homeWorkLocation")
    private HomeWorkLocation homeWorkLocation;
    @JsonProperty("assignedWorkLocations")
    private List<AssignedWorkLocation> assignedWorkLocations = null;
    @JsonProperty("remunerationBasisCode")
    private RemunerationBasisCode remunerationBasisCode;
    @JsonProperty("payCycleCode")
    private PayCycleCode payCycleCode;
    @JsonProperty("standardPayPeriodHours")
    private StandardPayPeriodHours standardPayPeriodHours;
    @JsonProperty("baseRemuneration")
    private BaseRemuneration baseRemuneration;
    @JsonProperty("additionalRemunerations")
    private List<AdditionalRemuneration> additionalRemunerations = null;
    @JsonProperty("reportsTo")
    private List<ReportsTo> reportsTo = null;
    @JsonProperty("payrollProcessingStatusCode")
    private PayrollProcessingStatusCode payrollProcessingStatusCode;
    @JsonProperty("payrollFileNumber")
    private String payrollFileNumber;
    @JsonProperty("payrollRegionCode")
    private String payrollRegionCode;
    @JsonProperty("payScaleCode")
    private PayScaleCode payScaleCode;
    @JsonProperty("payGradeCode")
    private PayGradeCode payGradeCode;
    @JsonProperty("payGradePayRange")
    private PayGradePayRange payGradePayRange;
    @JsonProperty("compaRatio")
    private Integer compaRatio;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();
    private final static long serialVersionUID = 6840345362463900494L;

    @JsonProperty("primaryIndicator")
    public Boolean getPrimaryIndicator() {
        return primaryIndicator;
    }

    @JsonProperty("primaryIndicator")
    public void setPrimaryIndicator(Boolean primaryIndicator) {
        this.primaryIndicator = primaryIndicator;
    }

    @JsonProperty("offerExtensionDate")
    public String getOfferExtensionDate() {
        return offerExtensionDate;
    }

    @JsonProperty("offerExtensionDate")
    public void setOfferExtensionDate(String offerExtensionDate) {
        this.offerExtensionDate = offerExtensionDate;
    }

    @JsonProperty("offerAcceptanceDate")
    public String getOfferAcceptanceDate() {
        return offerAcceptanceDate;
    }

    @JsonProperty("offerAcceptanceDate")
    public void setOfferAcceptanceDate(String offerAcceptanceDate) {
        this.offerAcceptanceDate = offerAcceptanceDate;
    }

    @JsonProperty("hireDate")
    public String getHireDate() {
        return hireDate;
    }

    @JsonProperty("hireDate")
    public void setHireDate(String hireDate) {
        this.hireDate = hireDate;
    }

    @JsonProperty("expectedStartDate")
    public String getExpectedStartDate() {
        return expectedStartDate;
    }

    @JsonProperty("expectedStartDate")
    public void setExpectedStartDate(String expectedStartDate) {
        this.expectedStartDate = expectedStartDate;
    }

    @JsonProperty("actualStartDate")
    public String getActualStartDate() {
        return actualStartDate;
    }

    @JsonProperty("actualStartDate")
    public void setActualStartDate(String actualStartDate) {
        this.actualStartDate = actualStartDate;
    }

    @JsonProperty("assignmentStatus")
    public AssignmentStatus getAssignmentStatus() {
        return assignmentStatus;
    }

    @JsonProperty("assignmentStatus")
    public void setAssignmentStatus(AssignmentStatus assignmentStatus) {
        this.assignmentStatus = assignmentStatus;
    }

    @JsonProperty("workerTypeCode")
    public WorkerTypeCode getWorkerTypeCode() {
        return workerTypeCode;
    }

    @JsonProperty("workerTypeCode")
    public void setWorkerTypeCode(WorkerTypeCode workerTypeCode) {
        this.workerTypeCode = workerTypeCode;
    }

    @JsonProperty("assignmentTermCode")
    public AssignmentTermCode getAssignmentTermCode() {
        return assignmentTermCode;
    }

    @JsonProperty("assignmentTermCode")
    public void setAssignmentTermCode(AssignmentTermCode assignmentTermCode) {
        this.assignmentTermCode = assignmentTermCode;
    }

    @JsonProperty("workLevelCode")
    public WorkLevelCode getWorkLevelCode() {
        return workLevelCode;
    }

    @JsonProperty("workLevelCode")
    public void setWorkLevelCode(WorkLevelCode workLevelCode) {
        this.workLevelCode = workLevelCode;
    }

    @JsonProperty("nationalityContextCode")
    public NationalityContextCode getNationalityContextCode() {
        return nationalityContextCode;
    }

    @JsonProperty("nationalityContextCode")
    public void setNationalityContextCode(NationalityContextCode nationalityContextCode) {
        this.nationalityContextCode = nationalityContextCode;
    }

    @JsonProperty("vipIndicator")
    public Boolean getVipIndicator() {
        return vipIndicator;
    }

    @JsonProperty("vipIndicator")
    public void setVipIndicator(Boolean vipIndicator) {
        this.vipIndicator = vipIndicator;
    }

    @JsonProperty("executiveIndicator")
    public Boolean getExecutiveIndicator() {
        return executiveIndicator;
    }

    @JsonProperty("executiveIndicator")
    public void setExecutiveIndicator(Boolean executiveIndicator) {
        this.executiveIndicator = executiveIndicator;
    }

    @JsonProperty("officerIndicator")
    public Boolean getOfficerIndicator() {
        return officerIndicator;
    }

    @JsonProperty("officerIndicator")
    public void setOfficerIndicator(Boolean officerIndicator) {
        this.officerIndicator = officerIndicator;
    }

    @JsonProperty("highlyCompensatedIndicator")
    public Boolean getHighlyCompensatedIndicator() {
        return highlyCompensatedIndicator;
    }

    @JsonProperty("highlyCompensatedIndicator")
    public void setHighlyCompensatedIndicator(Boolean highlyCompensatedIndicator) {
        this.highlyCompensatedIndicator = highlyCompensatedIndicator;
    }

    @JsonProperty("highlyCompensatedTypeCode")
    public HighlyCompensatedTypeCode getHighlyCompensatedTypeCode() {
        return highlyCompensatedTypeCode;
    }

    @JsonProperty("highlyCompensatedTypeCode")
    public void setHighlyCompensatedTypeCode(HighlyCompensatedTypeCode highlyCompensatedTypeCode) {
        this.highlyCompensatedTypeCode = highlyCompensatedTypeCode;
    }

    @JsonProperty("stockOwnerIndicator")
    public Boolean getStockOwnerIndicator() {
        return stockOwnerIndicator;
    }

    @JsonProperty("stockOwnerIndicator")
    public void setStockOwnerIndicator(Boolean stockOwnerIndicator) {
        this.stockOwnerIndicator = stockOwnerIndicator;
    }

    @JsonProperty("stockOwnerPercentage")
    public Double getStockOwnerPercentage() {
        return stockOwnerPercentage;
    }

    @JsonProperty("stockOwnerPercentage")
    public void setStockOwnerPercentage(Double stockOwnerPercentage) {
        this.stockOwnerPercentage = stockOwnerPercentage;
    }

    @JsonProperty("workerGroups")
    public List<WorkerGroup> getWorkerGroups() {
        return workerGroups;
    }

    @JsonProperty("workerGroups")
    public void setWorkerGroups(List<WorkerGroup> workerGroups) {
        this.workerGroups = workerGroups;
    }

    @JsonProperty("jobCode")
    public JobCode getJobCode() {
        return jobCode;
    }

    @JsonProperty("jobCode")
    public void setJobCode(JobCode jobCode) {
        this.jobCode = jobCode;
    }

    @JsonProperty("jobTitle")
    public String getJobTitle() {
        return jobTitle;
    }

    @JsonProperty("jobTitle")
    public void setJobTitle(String jobTitle) {
        this.jobTitle = jobTitle;
    }

    @JsonProperty("occupationalClassifications")
    public List<OccupationalClassification> getOccupationalClassifications() {
        return occupationalClassifications;
    }

    @JsonProperty("occupationalClassifications")
    public void setOccupationalClassifications(List<OccupationalClassification> occupationalClassifications) {
        this.occupationalClassifications = occupationalClassifications;
    }

    @JsonProperty("wageLawCoverage")
    public WageLawCoverage getWageLawCoverage() {
        return wageLawCoverage;
    }

    @JsonProperty("wageLawCoverage")
    public void setWageLawCoverage(WageLawCoverage wageLawCoverage) {
        this.wageLawCoverage = wageLawCoverage;
    }

    @JsonProperty("workArrangementCode")
    public WorkArrangementCode getWorkArrangementCode() {
        return workArrangementCode;
    }

    @JsonProperty("workArrangementCode")
    public void setWorkArrangementCode(WorkArrangementCode workArrangementCode) {
        this.workArrangementCode = workArrangementCode;
    }

    @JsonProperty("standardHours")
    public StandardHours getStandardHours() {
        return standardHours;
    }

    @JsonProperty("standardHours")
    public void setStandardHours(StandardHours standardHours) {
        this.standardHours = standardHours;
    }

    @JsonProperty("homeOrganizationalUnits")
    public List<HomeOrganizationalUnit> getHomeOrganizationalUnits() {
        return homeOrganizationalUnits;
    }

    @JsonProperty("homeOrganizationalUnits")
    public void setHomeOrganizationalUnits(List<HomeOrganizationalUnit> homeOrganizationalUnits) {
        this.homeOrganizationalUnits = homeOrganizationalUnits;
    }

    @JsonProperty("assignedOrganizationalUnits")
    public List<AssignedOrganizationalUnit> getAssignedOrganizationalUnits() {
        return assignedOrganizationalUnits;
    }

    @JsonProperty("assignedOrganizationalUnits")
    public void setAssignedOrganizationalUnits(List<AssignedOrganizationalUnit> assignedOrganizationalUnits) {
        this.assignedOrganizationalUnits = assignedOrganizationalUnits;
    }

    @JsonProperty("homeWorkLocation")
    public HomeWorkLocation getHomeWorkLocation() {
        return homeWorkLocation;
    }

    @JsonProperty("homeWorkLocation")
    public void setHomeWorkLocation(HomeWorkLocation homeWorkLocation) {
        this.homeWorkLocation = homeWorkLocation;
    }

    @JsonProperty("assignedWorkLocations")
    public List<AssignedWorkLocation> getAssignedWorkLocations() {
        return assignedWorkLocations;
    }

    @JsonProperty("assignedWorkLocations")
    public void setAssignedWorkLocations(List<AssignedWorkLocation> assignedWorkLocations) {
        this.assignedWorkLocations = assignedWorkLocations;
    }

    @JsonProperty("remunerationBasisCode")
    public RemunerationBasisCode getRemunerationBasisCode() {
        return remunerationBasisCode;
    }

    @JsonProperty("remunerationBasisCode")
    public void setRemunerationBasisCode(RemunerationBasisCode remunerationBasisCode) {
        this.remunerationBasisCode = remunerationBasisCode;
    }

    @JsonProperty("payCycleCode")
    public PayCycleCode getPayCycleCode() {
        return payCycleCode;
    }

    @JsonProperty("payCycleCode")
    public void setPayCycleCode(PayCycleCode payCycleCode) {
        this.payCycleCode = payCycleCode;
    }

    @JsonProperty("standardPayPeriodHours")
    public StandardPayPeriodHours getStandardPayPeriodHours() {
        return standardPayPeriodHours;
    }

    @JsonProperty("standardPayPeriodHours")
    public void setStandardPayPeriodHours(StandardPayPeriodHours standardPayPeriodHours) {
        this.standardPayPeriodHours = standardPayPeriodHours;
    }

    @JsonProperty("baseRemuneration")
    public BaseRemuneration getBaseRemuneration() {
        return baseRemuneration;
    }

    @JsonProperty("baseRemuneration")
    public void setBaseRemuneration(BaseRemuneration baseRemuneration) {
        this.baseRemuneration = baseRemuneration;
    }

    @JsonProperty("additionalRemunerations")
    public List<AdditionalRemuneration> getAdditionalRemunerations() {
        return additionalRemunerations;
    }

    @JsonProperty("additionalRemunerations")
    public void setAdditionalRemunerations(List<AdditionalRemuneration> additionalRemunerations) {
        this.additionalRemunerations = additionalRemunerations;
    }

    @JsonProperty("reportsTo")
    public List<ReportsTo> getReportsTo() {
        return reportsTo;
    }

    @JsonProperty("reportsTo")
    public void setReportsTo(List<ReportsTo> reportsTo) {
        this.reportsTo = reportsTo;
    }

    @JsonProperty("payrollProcessingStatusCode")
    public PayrollProcessingStatusCode getPayrollProcessingStatusCode() {
        return payrollProcessingStatusCode;
    }

    @JsonProperty("payrollProcessingStatusCode")
    public void setPayrollProcessingStatusCode(PayrollProcessingStatusCode payrollProcessingStatusCode) {
        this.payrollProcessingStatusCode = payrollProcessingStatusCode;
    }

    @JsonProperty("payrollFileNumber")
    public String getPayrollFileNumber() {
        return payrollFileNumber;
    }

    @JsonProperty("payrollFileNumber")
    public void setPayrollFileNumber(String payrollFileNumber) {
        this.payrollFileNumber = payrollFileNumber;
    }

    @JsonProperty("payrollRegionCode")
    public String getPayrollRegionCode() {
        return payrollRegionCode;
    }

    @JsonProperty("payrollRegionCode")
    public void setPayrollRegionCode(String payrollRegionCode) {
        this.payrollRegionCode = payrollRegionCode;
    }

    @JsonProperty("payScaleCode")
    public PayScaleCode getPayScaleCode() {
        return payScaleCode;
    }

    @JsonProperty("payScaleCode")
    public void setPayScaleCode(PayScaleCode payScaleCode) {
        this.payScaleCode = payScaleCode;
    }

    @JsonProperty("payGradeCode")
    public PayGradeCode getPayGradeCode() {
        return payGradeCode;
    }

    @JsonProperty("payGradeCode")
    public void setPayGradeCode(PayGradeCode payGradeCode) {
        this.payGradeCode = payGradeCode;
    }

    @JsonProperty("payGradePayRange")
    public PayGradePayRange getPayGradePayRange() {
        return payGradePayRange;
    }

    @JsonProperty("payGradePayRange")
    public void setPayGradePayRange(PayGradePayRange payGradePayRange) {
        this.payGradePayRange = payGradePayRange;
    }

    @JsonProperty("compaRatio")
    public Integer getCompaRatio() {
        return compaRatio;
    }

    @JsonProperty("compaRatio")
    public void setCompaRatio(Integer compaRatio) {
        this.compaRatio = compaRatio;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("primaryIndicator", primaryIndicator).append("offerExtensionDate", offerExtensionDate).append("offerAcceptanceDate", offerAcceptanceDate).append("hireDate", hireDate).append("expectedStartDate", expectedStartDate).append("actualStartDate", actualStartDate).append("assignmentStatus", assignmentStatus).append("workerTypeCode", workerTypeCode).append("assignmentTermCode", assignmentTermCode).append("workLevelCode", workLevelCode).append("nationalityContextCode", nationalityContextCode).append("vipIndicator", vipIndicator).append("executiveIndicator", executiveIndicator).append("officerIndicator", officerIndicator).append("highlyCompensatedIndicator", highlyCompensatedIndicator).append("highlyCompensatedTypeCode", highlyCompensatedTypeCode).append("stockOwnerIndicator", stockOwnerIndicator).append("stockOwnerPercentage", stockOwnerPercentage).append("workerGroups", workerGroups).append("jobCode", jobCode).append("jobTitle", jobTitle).append("occupationalClassifications", occupationalClassifications).append("wageLawCoverage", wageLawCoverage).append("workArrangementCode", workArrangementCode).append("standardHours", standardHours).append("homeOrganizationalUnits", homeOrganizationalUnits).append("assignedOrganizationalUnits", assignedOrganizationalUnits).append("homeWorkLocation", homeWorkLocation).append("assignedWorkLocations", assignedWorkLocations).append("remunerationBasisCode", remunerationBasisCode).append("payCycleCode", payCycleCode).append("standardPayPeriodHours", standardPayPeriodHours).append("baseRemuneration", baseRemuneration).append("additionalRemunerations", additionalRemunerations).append("reportsTo", reportsTo).append("payrollProcessingStatusCode", payrollProcessingStatusCode).append("payrollFileNumber", payrollFileNumber).append("payrollRegionCode", payrollRegionCode).append("payScaleCode", payScaleCode).append("payGradeCode", payGradeCode).append("payGradePayRange", payGradePayRange).append("compaRatio", compaRatio).append("additionalProperties", additionalProperties).toString();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(remunerationBasisCode).append(jobTitle).append(jobCode).append(homeOrganizationalUnits).append(primaryIndicator).append(stockOwnerPercentage).append(additionalRemunerations).append(officerIndicator).append(executiveIndicator).append(assignmentTermCode).append(highlyCompensatedIndicator).append(actualStartDate).append(stockOwnerIndicator).append(payCycleCode).append(payScaleCode).append(compaRatio).append(occupationalClassifications).append(assignmentStatus).append(vipIndicator).append(standardPayPeriodHours).append(expectedStartDate).append(baseRemuneration).append(payrollProcessingStatusCode).append(hireDate).append(homeWorkLocation).append(wageLawCoverage).append(nationalityContextCode).append(standardHours).append(reportsTo).append(workLevelCode).append(assignedOrganizationalUnits).append(payrollFileNumber).append(assignedWorkLocations).append(workerTypeCode).append(highlyCompensatedTypeCode).append(workArrangementCode).append(payrollRegionCode).append(offerExtensionDate).append(payGradeCode).append(additionalProperties).append(payGradePayRange).append(offerAcceptanceDate).append(workerGroups).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof WorkAssignment) == false) {
            return false;
        }
        WorkAssignment rhs = ((WorkAssignment) other);
        return new EqualsBuilder().append(remunerationBasisCode, rhs.remunerationBasisCode).append(jobTitle, rhs.jobTitle).append(jobCode, rhs.jobCode).append(homeOrganizationalUnits, rhs.homeOrganizationalUnits).append(primaryIndicator, rhs.primaryIndicator).append(stockOwnerPercentage, rhs.stockOwnerPercentage).append(additionalRemunerations, rhs.additionalRemunerations).append(officerIndicator, rhs.officerIndicator).append(executiveIndicator, rhs.executiveIndicator).append(assignmentTermCode, rhs.assignmentTermCode).append(highlyCompensatedIndicator, rhs.highlyCompensatedIndicator).append(actualStartDate, rhs.actualStartDate).append(stockOwnerIndicator, rhs.stockOwnerIndicator).append(payCycleCode, rhs.payCycleCode).append(payScaleCode, rhs.payScaleCode).append(compaRatio, rhs.compaRatio).append(occupationalClassifications, rhs.occupationalClassifications).append(assignmentStatus, rhs.assignmentStatus).append(vipIndicator, rhs.vipIndicator).append(standardPayPeriodHours, rhs.standardPayPeriodHours).append(expectedStartDate, rhs.expectedStartDate).append(baseRemuneration, rhs.baseRemuneration).append(payrollProcessingStatusCode, rhs.payrollProcessingStatusCode).append(hireDate, rhs.hireDate).append(homeWorkLocation, rhs.homeWorkLocation).append(wageLawCoverage, rhs.wageLawCoverage).append(nationalityContextCode, rhs.nationalityContextCode).append(standardHours, rhs.standardHours).append(reportsTo, rhs.reportsTo).append(workLevelCode, rhs.workLevelCode).append(assignedOrganizationalUnits, rhs.assignedOrganizationalUnits).append(payrollFileNumber, rhs.payrollFileNumber).append(assignedWorkLocations, rhs.assignedWorkLocations).append(workerTypeCode, rhs.workerTypeCode).append(highlyCompensatedTypeCode, rhs.highlyCompensatedTypeCode).append(workArrangementCode, rhs.workArrangementCode).append(payrollRegionCode, rhs.payrollRegionCode).append(offerExtensionDate, rhs.offerExtensionDate).append(payGradeCode, rhs.payGradeCode).append(additionalProperties, rhs.additionalProperties).append(payGradePayRange, rhs.payGradePayRange).append(offerAcceptanceDate, rhs.offerAcceptanceDate).append(workerGroups, rhs.workerGroups).isEquals();
    }

}
